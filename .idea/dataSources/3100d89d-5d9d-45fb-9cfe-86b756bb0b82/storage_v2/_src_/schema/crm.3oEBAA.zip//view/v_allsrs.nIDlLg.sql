create view v_allsrs as select
                          `crm`.`sr_servizi_richiesti`.`id`                                                       AS `id`,
                          `crm`.`sr_servizi_richiesti`.`name`                                                     AS `name`,
                          `crm`.`sr_servizi_richiesti`.`date_entered`                                             AS `date_entered`,
                          `crm`.`sr_servizi_richiesti`.`date_modified`                                            AS `date_modified`,
                          `crm`.`sr_servizi_richiesti`.`modified_user_id`                                         AS `modified_user_id`,
                          `crm`.`sr_servizi_richiesti`.`created_by`                                               AS `created_by`,
                          `crm`.`sr_servizi_richiesti`.`description`                                              AS `description`,
                          `crm`.`sr_servizi_richiesti`.`deleted`                                                  AS `deleted`,
                          `crm`.`sr_servizi_richiesti`.`assigned_user_id`                                         AS `assigned_user_id`,
                          `crm`.`sr_servizi_richiesti`.`lead_id_c`                                                AS `lead_id_c`,
                          `crm`.`sr_servizi_richiesti`.`centro_scelto`                                            AS `centro_scelto`,
                          `crm`.`sr_servizi_richiesti`.`servizio_scelto`                                          AS `servizio_scelto`,
                          `crm`.`sr_servizi_richiesti`.`num_uffici`                                               AS `num_uffici`,
                          `crm`.`sr_servizi_richiesti`.`num_postazioni`                                           AS `num_postazioni`,
                          `crm`.`accounts_sr_servizi_richiesti_1_c`.`accounts_sr_servizi_richiesti_1accounts_ida` AS `accountid`
                        from ((`crm`.`sr_servizi_richiesti`
                          join `crm`.`sr_servizi_richiesti_cstm`
                            on ((`crm`.`sr_servizi_richiesti`.`id` = `crm`.`sr_servizi_richiesti_cstm`.`id_c`))) join
                          `crm`.`accounts_sr_servizi_richiesti_1_c` on ((
                            `crm`.`accounts_sr_servizi_richiesti_1_c`.`accounts_sr_servizi_richiesti_1sr_servizi_richiesti_idb`
                            = `crm`.`sr_servizi_richiesti`.`id`)))
                        where (`crm`.`sr_servizi_richiesti`.`deleted` = 0)
                        union all select
                                    `crm`.`sr_servizi_richiesti`.`id`               AS `id`,
                                    `crm`.`sr_servizi_richiesti`.`name`             AS `name`,
                                    `crm`.`sr_servizi_richiesti`.`date_entered`     AS `date_entered`,
                                    `crm`.`sr_servizi_richiesti`.`date_modified`    AS `date_modified`,
                                    `crm`.`sr_servizi_richiesti`.`modified_user_id` AS `modified_user_id`,
                                    `crm`.`sr_servizi_richiesti`.`created_by`       AS `created_by`,
                                    `crm`.`sr_servizi_richiesti`.`description`      AS `description`,
                                    `crm`.`sr_servizi_richiesti`.`deleted`          AS `deleted`,
                                    `crm`.`sr_servizi_richiesti`.`assigned_user_id` AS `assigned_user_id`,
                                    `crm`.`sr_servizi_richiesti`.`lead_id_c`        AS `lead_id_c`,
                                    `crm`.`sr_servizi_richiesti`.`centro_scelto`    AS `centro_scelto`,
                                    `crm`.`sr_servizi_richiesti`.`servizio_scelto`  AS `servizio_scelto`,
                                    `crm`.`sr_servizi_richiesti`.`num_uffici`       AS `num_uffici`,
                                    `crm`.`sr_servizi_richiesti`.`num_postazioni`   AS `num_postazioni`,
                                    `crm`.`accounts`.`id`                           AS `accountid`
                                  from ((((`crm`.`sr_servizi_richiesti`
                                    join `crm`.`sr_servizi_richiesti_leads_c` on ((
                                      `crm`.`sr_servizi_richiesti_leads_c`.`sr_servizi_richiesti_leadssr_servizi_richiesti_idb`
                                      = `crm`.`sr_servizi_richiesti`.`id`))) join `crm`.`leads`
                                      on ((`crm`.`sr_servizi_richiesti_leads_c`.`sr_servizi_richiesti_leadsleads_ida` =
                                           `crm`.`leads`.`id`))) join `crm`.`leads_cstm`
                                      on ((`crm`.`leads`.`id` = `crm`.`leads_cstm`.`id_c`))) join `crm`.`accounts`
                                      on ((`crm`.`accounts`.`id` = `crm`.`leads_cstm`.`account_id_c`)))
                                  where (`crm`.`sr_servizi_richiesti`.`deleted` = 0);

