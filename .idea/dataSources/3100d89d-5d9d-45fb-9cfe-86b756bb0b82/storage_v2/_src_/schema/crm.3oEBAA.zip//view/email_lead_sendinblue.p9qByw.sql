create view email_lead_sendinblue as
  select
    `email_lead`.`first_name`                  AS `first_name`,
    `email_lead`.`last_name`                   AS `last_name`,
    `email_lead`.`email_address`               AS `email_address`,
    `email_lead`.`id`                          AS `id`,
    `email_lead`.`mobile`                      AS `mobile`,
    `email_lead`.`primario`                    AS `primario`,
    `crm`.`leads_cstm`.`cellulare_notifiche_c` AS `cellulare_notifiche_c`
  from (`crm`.`email_lead`
    join `crm`.`leads_cstm` on ((`email_lead`.`id` = `crm`.`leads_cstm`.`id_c`)))
  where
    ((`crm`.`leads_cstm`.`cellulare_notifiche_c` is not null) and (`crm`.`leads_cstm`.`cellulare_notifiche_c` <> ''));

