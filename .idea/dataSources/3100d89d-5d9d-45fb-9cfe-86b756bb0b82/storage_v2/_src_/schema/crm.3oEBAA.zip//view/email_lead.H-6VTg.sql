create view email_lead as
  select
    `crm`.`leads`.`first_name`                    AS `first_name`,
    `crm`.`leads`.`last_name`                     AS `last_name`,
    `crm`.`email_addresses`.`email_address`       AS `email_address`,
    `crm`.`leads`.`id`                            AS `id`,
    `crm`.`leads`.`phone_mobile`                  AS `mobile`,
    `crm`.`email_addr_bean_rel`.`primary_address` AS `primario`
  from ((`crm`.`leads`
    left join `crm`.`email_addr_bean_rel` on (((`crm`.`email_addr_bean_rel`.`bean_id` = `crm`.`leads`.`id`) and
                                               (`crm`.`email_addr_bean_rel`.`bean_module` = 'Leads') and
                                               (`crm`.`email_addr_bean_rel`.`deleted` = 0)))) left join
    `crm`.`email_addresses` on (((`crm`.`email_addresses`.`id` = `crm`.`email_addr_bean_rel`.`email_address_id`) and
                                 (`crm`.`email_addresses`.`deleted` = 0))))
  where (`crm`.`email_addresses`.`email_address` is not null);

