create view v_notes_history as select
                                 `crm`.`notes`.`id`         AS `v_note`,
                                 `crm`.`emails`.`parent_id` AS `v_lead_id`
                               from (`crm`.`notes`
                                 join `crm`.`emails` on ((`crm`.`notes`.`parent_id` = `crm`.`emails`.`id`)))
                               where ((`crm`.`notes`.`deleted` = 0) and (`crm`.`emails`.`deleted` = 0))
                               union all select
                                           `crm`.`notes`.`id`                                         AS `v_note`,
                                           `crm`.`leads_aos_quotes_1_c`.`leads_aos_quotes_1leads_ida` AS `v_lead_id`
                                         from ((`crm`.`notes`
                                           join `crm`.`aos_quotes`
                                             on ((`crm`.`notes`.`parent_id` = `crm`.`aos_quotes`.`id`))) join
                                           `crm`.`leads_aos_quotes_1_c`
                                             on ((`crm`.`leads_aos_quotes_1_c`.`id` = `crm`.`aos_quotes`.`id`)))
                                         where ((`crm`.`notes`.`deleted` = 0) and (`crm`.`aos_quotes`.`deleted` = 0));

